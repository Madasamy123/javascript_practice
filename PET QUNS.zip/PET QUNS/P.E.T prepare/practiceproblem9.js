//17. Write a program where an airplane climbs to a specific altitude(say 1000ft) over 10 intervals. 
//Use a for loop to display the altitude after each interval.

function airplane(n){
    for(let i=100;i<=n;){
        console.log(i);
       ;
    }
}
 airplane(1000);