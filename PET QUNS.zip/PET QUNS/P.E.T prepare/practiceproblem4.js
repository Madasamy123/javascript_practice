//12. Write a program where a robot must complete 10 laps around a circuit. Use a while loop to 
//count the laps and display the lap number each time the robot completes one.

function lapNumber(n){

for(let i=1;i<=n;i++){
    console.log("robot complete"+" "+i)
}
console.log("robot completes one")
}
lapNumber(10)
